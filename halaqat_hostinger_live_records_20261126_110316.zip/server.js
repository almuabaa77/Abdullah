import './halaqat-runtime.mjs'
